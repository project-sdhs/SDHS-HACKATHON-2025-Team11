const fetch = require('node-fetch');

const TMAP_API_KEY = 'WSl8QZIXM23C4gydo8ZKb8O7jrmxdThS1k1QuKti';

const TMAP_TRANSIT_URL = 'https://apis.openapi.sk.com/transit/routes';

exports.getTransitRoute = async (routeParams) => {
    try {
        const response = await fetch(TMAP_TRANSIT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'appKey': TMAP_API_KEY
            },
            body: JSON.stringify(routeParams)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || errorData.message || 'TMap API 호출 실패');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('TMap 서비스 오류:', error);
        throw error;
    }
};