exports.parseTmapTransitRoutes = (tmapApiResponse) => {
    const routes = [];

    if (!tmapApiResponse || !tmapApiResponse.metaData || !tmapApiResponse.metaData.plan || !tmapApiResponse.metaData.plan.itineraries) {
        console.error("TMap API 응답에서 itineraries를 찾을 수 없습니다.");
        return routes;
    }

    const parseLinestring = (linestring) => {
        if (typeof linestring === 'string' && linestring.length > 0) {
            return linestring.split(' ').map(pointStr => {
                const coords = pointStr.split(',').map(Number);
                if (coords.length === 2) {
                    return { lat: coords[1], lon: coords[0] };
                }
                return null;
            }).filter(coord => coord !== null);
        }
        return [];
    };

    tmapApiResponse.metaData.plan.itineraries.forEach(itinerary => {
        const totalTime = Math.ceil(itinerary.totalTime / 60);
        const totalFare = itinerary.fare.regular.totalFare;
        const transferCount = itinerary.transferCount;
        const legs = [];

        itinerary.legs.forEach(leg => {
            let coordinates = [];

            if (leg.mode === 'WALK') {
                if (leg.steps && Array.isArray(leg.steps)) {
                    leg.steps.forEach(step => {
                        coordinates = coordinates.concat(parseLinestring(step.linestring));
                    });
                }
            } else if (leg.mode === 'BUS' || leg.mode === 'SUBWAY') {
                if (leg.passShape && leg.passShape.linestring) {
                    coordinates = coordinates.concat(parseLinestring(leg.passShape.linestring));
                }
            }

            let lineName = null;
            if (leg.mode === 'SUBWAY') {
                lineName = leg.route || leg.routeNm || leg.line || null;
            } else if (leg.mode === 'BUS') {
                lineName = leg.route || leg.routeId || null;
            }

            legs.push({
                mode: leg.mode,
                startName: leg.start.name,
                endName: leg.end.name,
                distance: leg.distance,
                sectionTime: Math.ceil(leg.sectionTime / 60),
                routeId: leg.routeId || null,
                lineName: lineName,
                busNo: leg.mode === 'BUS' ? (leg.route || leg.routeId || null) : null,
                passStopCount: leg.passStopList ? leg.passStopList.stationList.length : 0,
                coordinates: coordinates,
                startStationId: leg.mode === 'SUBWAY' ? leg.start.id : null,
                startStationName: leg.mode === 'SUBWAY' ? leg.start.name : null,
                startStationLat: leg.mode === 'SUBWAY' ? leg.start.centerY : null,
                startStationLon: leg.mode === 'SUBWAY' ? leg.start.centerX : null,
                endStationId: leg.mode === 'SUBWAY' ? leg.end.id : null,
                endStationName: leg.mode === 'SUBWAY' ? leg.end.name : null,
                endStationLat: leg.mode === 'SUBWAY' ? leg.end.centerY : null,
                endStationLon: leg.mode === 'SUBWAY' ? leg.end.centerX : null,
                passStopList: leg.mode === 'BUS' ? leg.passStopList : null,
            });
        });

        routes.push({
            totalTime,
            totalFare,
            transferCount,
            legs,
        });
    });

    return routes;
};