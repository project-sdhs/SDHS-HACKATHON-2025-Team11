const fetch = require('node-fetch');
const xml2js = require('xml2js');

const SEOUL_BUS_API_KEY = '4c72456c4f62656435334d54727272';
const SEOUL_SUBWAY_API_KEY = '7a7358416362656437374d4a557772';

const SEOUL_BUS_ARRIVAL_API_URL = 'http://ws.bus.go.kr/api/rest/busArrivalService/getArrInfoByRoute';
const SEOUL_SUBWAY_ARRIVAL_API_BASE_URL = 'http://swopenapi.seoul.go.kr/api/subway';

exports.getBusArrivalInfo = async (busRouteId, stId) => {
    const encodedApiKey = encodeURIComponent(SEOUL_BUS_API_KEY);
    const url = `${SEOUL_BUS_ARRIVAL_API_URL}?serviceKey=${encodedApiKey}&busRouteId=${busRouteId}&stId=${stId}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Bus API call failed: ${response.status} ${response.statusText} - ${errorText}`);
        }
        const xmlText = await response.text();
        const parser = new xml2js.Parser({ explicitArray: false, ignoreAttrs: true });
        const result = await parser.parseStringPromise(xmlText);

        if (result?.ServiceResult?.msgHeader?.resultCode === '0') {
            return Array.isArray(result?.ServiceResult?.msgBody?.itemList) ? result.ServiceResult.msgBody.itemList : (result?.ServiceResult?.msgBody?.itemList ? [result.ServiceResult.msgBody.itemList] : []);
        } else if (result?.ServiceResult?.msgHeader?.resultCode === '4') {
            return [];
        } else {
            const errorMsg = result?.ServiceResult?.msgHeader?.resultMsg || 'Unknown error';
            throw new Error(`Bus API response error: ${errorMsg}`);
        }
    } catch (error) {
        console.error('Seoul Bus Data Service Error:', error);
        throw error;
    }
};

exports.getSubwayArrivalInfo = async (stationName) => {
    const encodedStationName = encodeURIComponent(stationName);
    const url = `${SEOUL_SUBWAY_ARRIVAL_API_BASE_URL}/${SEOUL_SUBWAY_API_KEY}/json/realtimeStationArrival/0/5/${encodedStationName}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Subway API call failed: ${response.status} ${response.statusText} - ${errorText}`);
        }
        const data = await response.json();

        if (data?.realtimeArrivalList) {
            return data.realtimeArrivalList;
        } else if (data?.errorMessage?.code === 'INFO-200') {
            return [];
        } else {
            const errorMsg = data?.errorMessage?.message || 'Unknown subway API error';
            throw new Error(`Subway API response error: ${errorMsg}`);
        }
    } catch (error) {
        console.error('Seoul Subway Data Service Error:', error);
        throw error;
    }
};