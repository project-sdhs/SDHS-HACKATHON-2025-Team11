const express = require('express');
const path = require('path');
const apiRoutes = require('./route/route');

const app = express();
const port = 3500;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

app.use('/api', apiRoutes);

app.listen(port, '0.0.0.0', () => {
    console.log(`서버 실행 중: http://localhost:${port}`);
});