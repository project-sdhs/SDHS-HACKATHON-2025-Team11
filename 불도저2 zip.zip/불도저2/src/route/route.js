const express = require('express');
const router = express.Router();

const routeController = require('../controller/apiRoute');

router.post('/get-inf', routeController.getRoute);

module.exports = router;