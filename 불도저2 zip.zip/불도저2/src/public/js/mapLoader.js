let mapInstance;

export function initMap() {
    const mapContainer = document.getElementById('map');
    const mapOption = {
        center: new kakao.maps.LatLng(37.566826, 126.9786567),
        level: 3
    };
    mapInstance = new kakao.maps.Map(mapContainer, mapOption);
    console.log('카카오맵이 로드되었습니다.');
}

export function getMapInstance() {
    return mapInstance;
}