// public/js/loading.js
const loadingBack = document.querySelector('.loading-back');

export function showLoading() {
    if (loadingBack) {
        loadingBack.style.display = 'flex';
    }
}

export function hideLoading() {
    if (loadingBack) {
        loadingBack.style.display = 'none';
    }
}