export async function fetchRouteFromBackend(startX, startY, startName, endX, endY, endName, reqDTime) {
    try {
        const response = await fetch('/api/get-inf', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                startX,
                startY,
                startName,
                endX,
                endY,
                endName,
                reqDTime,
            }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || '알 수 없는 서버 오류 발생');
        }

        return await response.json();
    } catch (error) {
        console.error('백엔드 API 호출 중 오류 발생:', error);
        throw error;
    }
}