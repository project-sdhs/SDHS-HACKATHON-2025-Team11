const ps = new kakao.maps.services.Places();
let debounceTimer;

const searchPlaces = (keyword, dropdownElement, inputElement) => {
    if (!keyword.trim()) {
        dropdownElement.style.display = 'none';
        return;
    }

    ps.keywordSearch(keyword, (data, status) => {
        if (status === kakao.maps.services.Status.OK) {
            displayDropdown(data, dropdownElement, inputElement);
        } else {
            dropdownElement.style.display = 'none';
        }
    });
};

const displayDropdown = (places, dropdownElement, inputElement) => {
    dropdownElement.innerHTML = '';
    
    if (places.length === 0) {
        dropdownElement.style.display = 'none';
        return;
    }

    places.forEach(place => {
        const item = document.createElement('div');
        item.className = 'dropdown-item';
        item.innerHTML = `
            <div>${place.place_name}</div>
            <div style="font-size:0.8em;color:#888;">${place.address_name}</div>
        `;
        item.onclick = () => {
            inputElement.value = place.place_name;
            inputElement.dataset.x = place.x;
            inputElement.dataset.y = place.y;
            inputElement.dataset.address = place.address_name;
            dropdownElement.style.display = 'none';
        };
        dropdownElement.appendChild(item);
    });
    dropdownElement.style.display = 'block';
};

export function setupPlaceSearch(inputId, dropdownId) {
    const inputElement = document.getElementById(inputId);
    const dropdownElement = document.getElementById(dropdownId);

    inputElement.addEventListener('keyup', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            searchPlaces(e.target.value, dropdownElement, inputElement);
        }, 300);
    });
}

export function getSelectedPlaceCoords(inputElement) {
    const x = inputElement.dataset.x;
    const y = inputElement.dataset.y;
    const name = inputElement.value;
    const address = inputElement.dataset.address;

    if (x && y) {
        return { x: parseFloat(x), y: parseFloat(y), name: name, address: address };
    }
    return null;
}