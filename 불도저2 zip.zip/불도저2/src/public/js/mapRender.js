// public/js/mapRender.js
import { getMapInstance } from './mapLoader.js';

let currentMarkers = []; // 일반 마커 (출발/도착/중간 경유지 점 마커 포함)
let currentPolylines = [];
let currentCustomOverlays = []; // 구간 시간 표시 오버레이
let currentCongestionMarkers = []; // 혼잡도 정보 오버레이

export function clearMapElements() {
    currentMarkers.forEach(marker => marker.setMap(null));
    currentMarkers = [];
    currentPolylines.forEach(polyline => polyline.setMap(null));
    currentPolylines = [];
    currentCustomOverlays.forEach(overlay => overlay.setMap(null));
    currentCustomOverlays = []; // 이 부분에 오타가 있었습니다.
    currentCongestionMarkers.forEach(marker => marker.setMap(null));
    currentCongestionMarkers = [];
}

export const SUBWAY_LINE_COLORS = {
    '수도권1호선': '#00369D',
    '수도권2호선': '#00A84D',
    '수도권3호선': '#EF7C1E',
    '수도권4호선': '#00A5DE',
    '수도권5호선': '#996CAC',
    '수도권6호선': '#CD7C2F',
    '수도권7호선': '#747F00',
    '수도권8호선': '#EA545D',
    '수도권9호선': '#BDB092',
    '경의중앙선': '#73C8AE',
    '경강선': '#00B4B4',
    '수인분당선': '#F5A21E',
    '신분당선': '#D4003B',
    '인천1호선': '#7CBB7F',
    '인천2호선': '#F5A21E', // 인천2호선은 분당선과 색이 겹치므로 다른 색을 사용하거나 조정 필요
    '공항철도': '#0070C0',
    '우이신설선': '#B7CE00',
    '서해선': '#8EC62F',
    // 다른 노선 색상도 여기에 추가
    'OTHER': '#888888' // 기본 색상
};


export function displayRoutes(route, startPlace, endPlace) {
    const map = getMapInstance();
    if (!map) {
        console.error("Map instance is not available.");
        return;
    }

    clearMapElements(); // Clear existing elements before drawing new ones

    const bounds = new kakao.maps.LatLngBounds();

    // 1. 출발지 마커 (기본 마커)
    const startPos = new kakao.maps.LatLng(startPlace.y, startPlace.x);
    const startMarker = new kakao.maps.Marker({
        map: map,
        position: startPos,
        // image: null // 기본 마커를 사용하므로 이미지 설정 제거
    });
    currentMarkers.push(startMarker);
    bounds.extend(startPos);

    // 2. 도착지 마커 (기본 마커)
    const endPos = new kakao.maps.LatLng(endPlace.y, endPlace.x);
    const endMarker = new kakao.maps.Marker({
        map: map,
        position: endPos,
        // image: null // 기본 마커를 사용하므로 이미지 설정 제거
    });
    currentMarkers.push(endMarker);
    bounds.extend(endPos);


    // 출발지 정보 오버레이 (마커 위에 텍스트)
    const startOverlayContent = `<div style="padding:5px;background-color:#fff;border:1px solid #ccc;border-radius:5px;white-space:nowrap;">${startPlace.name}</div>`;
    const startCustomOverlay = new kakao.maps.CustomOverlay({
        map: map,
        position: startPos,
        content: startOverlayContent,
        yAnchor: 2 // 마커 위쪽으로 조정
    });
    currentMarkers.push(startCustomOverlay); // CustomOverlay도 마커 배열에 넣어 함께 관리

    // 도착지 정보 오버레이
    const endOverlayContent = `<div style="padding:5px;background-color:#fff;border:1px solid #ccc;border-radius:5px;white-space:nowrap;">${endPlace.name}</div>`;
    const endCustomOverlay = new kakao.maps.CustomOverlay({
        map: map,
        position: endPos,
        content: endOverlayContent,
        yAnchor: 2 // 마커 위쪽으로 조정
    });
    currentMarkers.push(endCustomOverlay); // CustomOverlay도 마커 배열에 넣어 함께 관리


    route.legs.forEach((leg, index) => {
        if (leg.coordinates && leg.coordinates.length > 0) {
            const path = leg.coordinates.map(coord => new kakao.maps.LatLng(coord.lat, coord.lon));

            let polylineOptions = {
                path: path,
                strokeWeight: 6,
                strokeOpacity: 0.9,
                strokeStyle: 'solid'
            };

            let iconClass = '';

            if (leg.mode === 'WALK') {
                polylineOptions.strokeColor = '#FFA500'; // Orange for walk
                polylineOptions.strokeStyle = 'dashed'; // Dashed line for walk
                iconClass = 'walk-icon';
            } else if (leg.mode === 'BUS') {
                polylineOptions.strokeColor = '#4CAF50'; // Green for bus
                iconClass = 'bus-icon';
                // 버스 혼잡도 정보 표시 (버스 노선 시작점에 표시)
                if (leg.passStopList && leg.busArrivalInfo && leg.busArrivalInfo.length > 0) {
                    const startBusStopPos = new kakao.maps.LatLng(leg.passStopList.stationList[0].stationLat, leg.passStopList.stationList[0].stationLon);
                    let arrivalInfoHtml = '<div class="congestion-overlay bus-arrival">';
                    arrivalInfoHtml += `<span>${leg.passStopList.stationList[0].stationName} (${leg.busNo}번)</span><br>`;
                    leg.busArrivalInfo.slice(0, 2).forEach(info => {
                        arrivalInfoHtml += `<span>${info.arr_time} 후 도착 (${info.arr_msg1})</span><br>`;
                    });
                    arrivalInfoHtml += '</div>';

                    const congestionOverlay = new kakao.maps.CustomOverlay({
                        map: map,
                        position: startBusStopPos,
                        content: arrivalInfoHtml,
                        yAnchor: 2.5
                    });
                    currentCongestionMarkers.push(congestionOverlay);
                }

            } else if (leg.mode === 'SUBWAY') {
                // 지하철 노선 색상 적용
                polylineOptions.strokeColor = SUBWAY_LINE_COLORS[leg.lineName] || SUBWAY_LINE_COLORS['OTHER'];
                iconClass = 'subway-icon';

                // 지하철 혼잡도 정보 표시 (지하철 노선 시작점에 표시)
                if (leg.subwayArrivalInfo && leg.subwayArrivalInfo.length > 0) {
                    const startStationPos = new kakao.maps.LatLng(leg.startStationLat, leg.startStationLon);
                    let arrivalInfoHtml = '<div class="congestion-overlay subway-arrival">';
                    arrivalInfoHtml += `<span>${leg.startStationName}</span><br>`;
                    leg.subwayArrivalInfo.slice(0, 2).forEach(info => {
                        let lineDisplay = info.subwayId;
                        // 특정 subwayId에 대한 display name 매핑 (예: 공항철도, 수인분당선)
                        if (info.subwayId === '1065') lineDisplay = '공항철도';
                        else if (info.subwayId === '1075') lineDisplay = '수인분당선';
                        else if (info.subwayId === '1001') lineDisplay = '1호선'; // 예시
                        else if (info.subwayId === '1002') lineDisplay = '2호선'; // 예시
                        // ... 필요한 다른 노선 ID에 대한 매핑 추가

                        arrivalInfoHtml += `<span class="subway-line-name">Line ${lineDisplay}</span> <span class="subway-direction">${info.updnLine}행</span><br>`;
                        if (info.arvlMsg2) {
                            arrivalInfoHtml += `<span class="subway-arvlmsg">${info.arvlMsg2}</span><br>`;
                        }
                    });
                    arrivalInfoHtml += '</div>';

                    const congestionOverlay = new kakao.maps.CustomOverlay({
                        map: map,
                        position: startStationPos, // 혼잡도는 시작역에만 표시
                        content: arrivalInfoHtml,
                        yAnchor: 2.5 // 마커와 겹치지 않게 아래로 조정
                    });
                    currentCongestionMarkers.push(congestionOverlay);
                }
            } else {
                polylineOptions.strokeColor = '#888'; // Default color for other modes
            }

            const polyline = new kakao.maps.Polyline(polylineOptions);
            polyline.setMap(map);
            currentPolylines.push(polyline);

            // 폴리라인의 모든 점을 경계에 포함
            path.forEach(p => bounds.extend(p));

            // 각 구간의 시작점에 아이콘과 시간 표시 (첫 구간이 도보면 출발지 마커와 겹치므로 두 번째 구간부터)
            if (leg.sectionTime > 0) { // 시간이 0분인 구간은 표시하지 않음
                const legStartPos = path[0];
                let content = `<div class="route-leg-overlay ${iconClass}">`;

                if (leg.mode === 'WALK') {
                    content += `<span class="icon">🚶</span>`;
                } else if (leg.mode === 'BUS') {
                    content += `<span class="icon">🚌</span>`;
                } else if (leg.mode === 'SUBWAY') {
                    content += `<span class="icon">🚇</span>`;
                }
                
                content += `<span class="time">${leg.sectionTime}분</span>`;
                content += `</div>`;

                const legOverlay = new kakao.maps.CustomOverlay({
                    map: map,
                    position: legStartPos,
                    content: content,
                    yAnchor: 1.5 // 오버레이 위치 조정
                });
                currentCustomOverlays.push(legOverlay);
            }

        } else {
            console.warn('폴리라인을 그릴 좌표 데이터가 부족하거나 없습니다:', leg.mode, leg.startName, leg.endName, leg.coordinates);
        }
    });

    // 지도 영역을 경로에 맞게 재설정
    if (!bounds.isEmpty()) {
        map.setBounds(bounds);
    }
}