// public/js/timeHandler.js
const departureTimeInput = document.getElementById('departureTime');
const todayTimeBtn = document.querySelector('.todayTime-btn');

export function initTimeHandler() {
    setCurrentTime(); // 페이지 로드 시 현재 시간으로 기본 설정
    todayTimeBtn.addEventListener('click', setCurrentTime); // '지금 출발' 버튼 클릭 시 현재 시간으로 재설정
}

export function setCurrentTime() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    departureTimeInput.value = `${hours}:${minutes}`;
}

export function getDepartureTimeFormatted() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    
    const timeValue = departureTimeInput.value;
    if (!timeValue) {
        throw new Error('출발 시간을 입력해주세요.');
    }
    // TMap API 요청 형식에 맞춰 YYYYMMDDHHMMSS 형식으로 변환
    return `${year}${month}${day}${timeValue.replace(':', '')}`;
}