// public/js/routeDisplay.js
import { displayRoutes as renderMapRoutes } from './mapRender.js';

const routeListContainer = document.getElementById('routeListContainer');
const routeList = document.getElementById('routeList');
const noResultsMessage = routeListContainer.querySelector('.no-results-message');

const formatTime = (timeStr) => {
    if (!timeStr || timeStr.length < 14) return '정보없음';
    const hour = timeStr.substring(8, 10);
    const minute = timeStr.substring(10, 12);
    return `${hour}:${minute}`;
};

export function clearRouteList() {
    routeList.innerHTML = '';
    noResultsMessage.style.display = 'none';
    routeListContainer.style.display = 'block';
}

export function showNoResultsMessage() {
    noResultsMessage.style.display = 'block';
    routeListContainer.style.display = 'block';
    routeList.innerHTML = ''; // 기존 목록 비우기
}

export function displayRouteResults(routes, startPlace, endPlace) {
    if (!routes || routes.length === 0) {
        showNoResultsMessage();
        return;
    }

    clearRouteList(); // 다시 그리기 전에 목록 초기화

    routes.forEach((route, index) => {
        const routeItem = document.createElement('div');
        routeItem.className = 'route-item';
        if (index === 0) {
            routeItem.classList.add('active');
        }
        routeItem.dataset.routeIndex = index;

        let totalTimeDisplay = '';
        if (route.totalTime) {
            const hours = Math.floor(route.totalTime / 60);
            const minutes = route.totalTime % 60;
            totalTimeDisplay = `${hours > 0 ? hours + '시간 ' : ''}${minutes}분`;
        }

        let visualSummaryHtml = '<div class="route-visual-summary">';
        route.legs.forEach(leg => {
            let icon = '';
            let info = '';
            let color = '';
            // 각 구간의 총 시간이 0일 경우, 전체 시간에서 차지하는 비율 계산 시 오류 방지를 위해 최소 너비 확보
            let width = (leg.sectionTime / route.totalTime) * 100; 
            if (width < 5 && leg.sectionTime > 0) { // 작은 구간도 보이게 최소 비율 설정
                width = 5;
            } else if (leg.sectionTime === 0) {
                width = 0; // 시간이 0분인 구간은 너비 0
            }


            if (leg.mode === 'WALK') {
                icon = '🚶';
                info = `${leg.sectionTime}분`;
                color = '#FFA500';
            } else if (leg.mode === 'BUS') {
                icon = '🚌';
                info = `${leg.busNo} (${leg.sectionTime}분)`;
                color = '#FFD700';
            } else if (leg.mode === 'SUBWAY') {
                icon = '🚇';
                info = `${leg.lineName} (${leg.sectionTime}분)`;
                color = '#007bff';
            }
            visualSummaryHtml += `
                <div class="leg-segment">
                    <span class="leg-icon">${icon}</span>
                    <span class="leg-info">${info}</span>
                    <div class="leg-time-bar" style="background-color: ${color}; width: ${width}%;"></div>
                </div>
            `;
        });
        visualSummaryHtml += '</div>';

        let routeArrivalSummaryHtml = '<div class="route-arrival-summary">';
        if (route.totalWalkTime) {
            routeArrivalSummaryHtml += `<span>총 도보 ${route.totalWalkTime}분</span>`;
        }
        if (route.firstStartExit && route.firstStartExit.exitNo) {
            routeArrivalSummaryHtml += `<span>첫 출발지 출구: ${route.firstStartExit.exitNo}번 출구</span>`;
        }
        routeArrivalSummaryHtml += '</div>';

        let legDetailsHtml = '<div class="route-leg-details-list">';
        route.legs.forEach(leg => {
            let legDetail = `<div class="leg-detail-item">`;
            let departureTimeFormatted = '';
            let arrivalTimeFormatted = '';

            if (leg.departureTime) {
                departureTimeFormatted = formatTime(leg.departureTime);
            }
            if (leg.arrivalTime) {
                arrivalTimeFormatted = formatTime(leg.arrivalTime);
            }

            if (leg.mode === 'WALK') {
                legDetail += `
                    <span class="leg-mode-icon">🚶</span>
                    <span>${leg.startName}에서 ${leg.endName}까지 도보 ${leg.sectionTime}분 (${leg.distance}m)</span>
                `;
            } else if (leg.mode === 'BUS') {
                legDetail += `
                    <span class="leg-mode-icon">🚌</span>
                    <span>[${leg.busNo}번] ${leg.startName} (${departureTimeFormatted}) → ${leg.endName} (${arrivalTimeFormatted}) ${leg.sectionTime}분</span>
                    <span class="stop-count">(${leg.passStopCount}개 정류장 이동)</span>
                `;
                if (leg.busArrivalInfo && leg.busArrivalInfo.length > 0) {
                    legDetail += `<div class="arrival-info">`;
                    leg.busArrivalInfo.forEach(info => {
                        legDetail += `<span>${info.plainNo}번 ${info.arrmsg1}</span>`;
                    });
                    legDetail += `</div>`;
                }
            } else if (leg.mode === 'SUBWAY') {
                legDetail += `
                    <span class="leg-mode-icon">🚇</span>
                    <span>[${leg.lineName}] ${leg.startName} (${departureTimeFormatted}) → ${leg.endName} (${arrivalTimeFormatted}) ${leg.sectionTime}분</span>
                    <span class="stop-count">(${leg.passStopCount}개 정류장 이동)</span>
                `;
                if (leg.subwayArrivalInfo && leg.subwayArrivalInfo.length > 0) {
                    legDetail += `<div class="arrival-info">`;
                    leg.subwayArrivalInfo.slice(0, 2).forEach(info => {
                        let lineDisplay = info.subwayId;
                        if (info.subwayId === '1065') lineDisplay = '공항철도';
                        else if (info.subwayId === '1075') lineDisplay = '수인분당선';
                        legDetail += `<span>${lineDisplay} ${info.updnLine}행 ${info.arvlMsg2}</span>`;
                    });
                    legDetail += `</div>`;
                }
            }
            legDetailsHtml += `${legDetail}</div>`;
        });
        legDetailsHtml += '</div>';

        routeItem.innerHTML = `
            <div class="route-summary">
                <div class="total-time">${totalTimeDisplay}</div>
                <div class="total-fare">${route.totalFare.toLocaleString()}원</div>
                <div class="transfer-count">환승 ${route.transferCount}회</div>
            </div>
            ${visualSummaryHtml}
            ${routeArrivalSummaryHtml}
            <div class="route-leg-details">
                ${legDetailsHtml}
            </div>
        `;
        routeList.appendChild(routeItem);

        routeItem.addEventListener('click', () => {
            document.querySelectorAll('.route-item').forEach(item => {
                item.classList.remove('active');
            });
            routeItem.classList.add('active');
            renderMapRoutes(routes[routeItem.dataset.routeIndex], startPlace, endPlace);
        });
    });

    renderMapRoutes(routes[0], startPlace, endPlace); // 초기 로드 시 첫 번째 경로 그리기
}

export function showErrorMessage(message) {
    noResultsMessage.textContent = `오류 발생: ${message}`;
    noResultsMessage.style.display = 'block';
    routeListContainer.style.display = 'block';
    routeList.innerHTML = ''; // 기존 목록 비우기
}