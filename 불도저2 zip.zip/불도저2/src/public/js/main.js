// public/js/main.js
import { setupPlaceSearch, getSelectedPlaceCoords } from './places.js';
import { initMap } from './mapLoader.js';
import { clearMapElements } from './mapRender.js';
import { fetchRouteFromBackend } from './apiService.js';
import { showLoading, hideLoading } from './loading.js'; // 로딩 모듈 임포트
import { initTimeHandler, getDepartureTimeFormatted } from './timeHandler.js'; // 시간 핸들러 모듈 임포트
import { displayRouteResults, showNoResultsMessage, showErrorMessage, clearRouteList } from './routeDisplay.js'; // 경로 표시 모듈 임포트

document.addEventListener('DOMContentLoaded', () => {
    initMap();
    setupPlaceSearch('startAddress', 'startDropdown');
    setupPlaceSearch('endAddress', 'endDropdown');
    initTimeHandler(); // 시간 핸들러 초기화

    const findPathBtn = document.getElementById('findPathBtn');
    const startAddressInput = document.getElementById('startAddress');
    const endAddressInput = document.getElementById('endAddress');

    findPathBtn.addEventListener('click', async () => {
        showLoading(); // 로딩 애니메이션 표시

        const startPlace = getSelectedPlaceCoords(startAddressInput);
        const endPlace = getSelectedPlaceCoords(endAddressInput);

        if (!startPlace || !endPlace) {
            alert('출발지와 도착지를 정확히 입력하고 드롭다운에서 선택해주세요.');
            hideLoading(); // 에러 발생 시 로딩 애니메이션 숨김
            return;
        }

        clearMapElements(); // 지도 요소 초기화
        clearRouteList(); // 경로 목록 초기화

        try {
            const reqDTime = getDepartureTimeFormatted(); // 시간을 가져오는 함수 호출

            const result = await fetchRouteFromBackend(
                startPlace.x,
                startPlace.y,
                startPlace.name || startPlace.address,
                endPlace.x,
                endPlace.y,
                endPlace.name || endPlace.address,
                reqDTime
            );

            if (result.success && result.routes && result.routes.length > 0) {
                displayRouteResults(result.routes, startPlace, endPlace); // 경로 결과 표시
                console.log("모든 경로 데이터:", result.routes);
            } else {
                showNoResultsMessage(); // 결과 없음 메시지 표시
                console.log("경로를 찾을 수 없습니다.");
            }
        } catch (error) {
            console.error('경로 찾기 중 오류 발생:', error);
            showErrorMessage(error.message || '경로를 찾는 중 오류가 발생했습니다. 다시 시도해주세요.');
        } finally {
            hideLoading(); // 성공 또는 실패와 관계없이 로딩 애니메이션 숨김
        }
    });
});





