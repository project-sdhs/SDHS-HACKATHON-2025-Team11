const tmapService = require('../services/tmapService');
const routeParser = require('../services/routeParser');
const seoulOpenDataService = require('../services/seoulOpenDataService');

exports.getRoute = async (req, res) => {
    const { startX, startY, startName, endX, endY, endName, reqDTime } = req.body;

    if (!startX || !startY || !endX || !endY || !reqDTime) {
        return res.status(400).json({ error: 'Missing required request data.' });
    }

    const tmapRequestBody = {
        startX: parseFloat(startX),
        startY: parseFloat(startY),
        endX: parseFloat(endX),
        endY: parseFloat(endY),
        reqDTime: reqDTime,
        lang: 'ko',
        format: 'json',
        startName: startName,
        endName: endName
    };

    try {
        const tmapApiResponse = await tmapService.getTransitRoute(tmapRequestBody);
        
        let routes = routeParser.parseTmapTransitRoutes(tmapApiResponse);

        if (!routes || routes.length === 0) {
            return res.json({ success: true, routes: [] });
        }

        const MAX_ROUTES = 7;
        if (routes.length > MAX_ROUTES) {
            routes = routes.slice(0, MAX_ROUTES);
        }

        const allPublicDataPromises = [];

        routes.forEach((route, routeIndex) => {
            route.legs.forEach((leg, legIndex) => {
                if (leg.mode === 'BUS' && leg.passStopList && leg.passStopList.stationList && leg.routeId) {
                    leg.passStopList.stationList.forEach(station => {
                        allPublicDataPromises.push(
                            seoulOpenDataService.getBusArrivalInfo(leg.routeId, station.stationID)
                                .then(arrivalInfo => ({
                                    routeIndex,
                                    legIndex,
                                    type: 'bus',
                                    stationID: station.stationID,
                                    stationName: station.stationName,
                                    arrivalInfo
                                }))
                                .catch(error => {
                                    console.error(`Bus arrival info fetch error for route ${leg.routeId}, station ${station.stationID}:`, error.message);
                                    return { routeIndex, legIndex, type: 'bus', stationID: station.stationID, stationName: station.stationName, arrivalInfo: [], error: error.message };
                                })
                        );
                    });
                }

                if (leg.mode === 'SUBWAY' && leg.startStationName) {
                    allPublicDataPromises.push(
                        seoulOpenDataService.getSubwayArrivalInfo(leg.startStationName)
                            .then(arrivalInfo => ({
                                routeIndex,
                                legIndex,
                                type: 'subway',
                                stationID: leg.startStationId,
                                stationName: leg.startStationName,
                                arrivalInfo
                            }))
                            .catch(error => {
                                console.error(`Subway arrival info fetch error for ${leg.startStationName}:`, error.message);
                                return { routeIndex, legIndex, type: 'subway', stationID: leg.startStationId, stationName: leg.startStationName, arrivalInfo: [], error: error.message };
                            })
                    );
                }
            });
        });

        const allPublicDataResults = await Promise.allSettled(allPublicDataPromises);

        allPublicDataResults.forEach(result => {
            if (result.status === 'fulfilled' && result.value?.arrivalInfo) {
                const { routeIndex, legIndex, type, stationID, stationName, arrivalInfo } = result.value;
                const targetRoute = routes[routeIndex];
                const targetLeg = targetRoute?.legs[legIndex];

                if (targetLeg) {
                    if (type === 'bus' && targetLeg.passStopList?.stationList) {
                        const targetStation = targetLeg.passStopList.stationList.find(s => s.stationID === stationID);
                        if (targetStation) {
                            targetStation.busArrivalInfo = arrivalInfo;
                        }
                    } else if (type === 'subway' && targetLeg.startStationId === stationID) {
                        targetLeg.subwayArrivalInfo = arrivalInfo;
                    }
                }
            } else if (result.status === 'rejected') {
                console.error("Public data request failed:", result.reason);
            }
        });
        
        res.json({ success: true, routes: routes });

    } catch (error) {
        console.error('경로 조회 처리 중 오류 발생:', error);
        res.status(500).json({ error: error.message || '서버 내부 오류가 발생했습니다.' });
    }
};